from frappe import _

def get_data():
	return [
		{
			"module_name": "Abtl Addon",
			"type": "module",
			"label": _("Abtl Addon")
		}
	]
