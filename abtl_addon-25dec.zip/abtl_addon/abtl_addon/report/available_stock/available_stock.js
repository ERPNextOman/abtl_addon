// Copyright (c) 2023, envisionx Oman and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Available Stock"] = {
	"filters": [

	]
};
