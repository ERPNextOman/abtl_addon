// Copyright (c) 2023, envisionx Oman and contributors
// For license information, please see license.txt

frappe.ui.form.on('Customer Type', {
	// refresh: function(frm) {

	// }
});
