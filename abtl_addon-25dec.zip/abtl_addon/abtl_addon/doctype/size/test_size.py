# Copyright (c) 2023, envisionx Oman and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSize(FrappeTestCase):
	pass
